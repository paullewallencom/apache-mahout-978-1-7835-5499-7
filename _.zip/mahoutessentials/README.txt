Apache Mahout Essentials

=================================
Instructions to try code examples
=================================

The code examples are given as a Maven project.

1. Instructions to download and install Maven:
https://maven.apache.org/download.cgi
https://maven.apache.org/download.cgi#Installation

2. Download Mahout v0.9:
https://mahout.apache.org/general/downloads.html

3. Add to Maven repository:
http://maven.apache.org/general.html#importing-jars

4. Setting up examples in Eclipse:
File > Import > Maven > Existing Maven Projects > Select Root directory as given “mahout essentials” folder > Finish